package persistence.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import model.PromocionAxB;
import model.PromocionPorcentual;
import model.TipoAtraccion;
import model.PromocionAbsoluta;

import persistence.PromocionDAO;
import persistence.commons.ConnectionProvider;
import persistence.commons.MissingDataException;
import model.Atraccion;
import model.Promocion;


public class PromocionDAOImpl implements PromocionDAO {

	private AtraccionDAOImpl atraccionDao;

	public PromocionDAOImpl() {
		this.atraccionDao = new AtraccionDAOImpl();
	}

	public Promocion findByNombre(String nombre) {
		try {
			String sql = "SELECT * FROM Promocion WHERE Nombre = ?";
			Connection conn = ConnectionProvider.getConnection();
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setString(1, nombre);
			ResultSet resultados = statement.executeQuery();

			Promocion promocion = null;

			if (resultados.next()) {
				promocion = toPromo(resultados);
			}

			return promocion;
		} catch (Exception e) {
			throw new MissingDataException(e);
		}
	}
	
	/*
	 * Inserta una promocion nueva en la base de datos
	 */
	@Override
	public int insert(Promocion promocion) throws SQLException {
		String sql = "INSERT INTO Promocion  ( ID_Atraccion1, ID_Atraccion2, nombre ,Tipo,monto,Tiempo,AtraccionGratis,Descuento,PromocionTipo) VALUES "
				+ "((SELECT ID_Atraccion FROM Atraccion WHERE Nombre = ?),(SELECT ID_Atraccion FROM Atraccion WHERE Nombre = ?),?,?,?,?,(SELECT ID_Atraccion FROM Atraccion WHERE Nombre = ?),?,?)";
		Connection conn = ConnectionProvider.getConnection();

		PreparedStatement statement = conn.prepareStatement(sql);

		statement.setObject(1, promocion.getPackAtracciones()[0].getNombre());//
		statement.setObject(2, promocion.getPackAtracciones()[1].getNombre());//

		statement.setString(3, promocion.getNombre());
		statement.setObject(4, promocion.getTipo());
		statement.setDouble(6, promocion.getTiempo());

		if (promocion.getClass().getSimpleName().equals(PromocionAxB.class.getSimpleName())) {
			statement.setObject(7, ((PromocionAxB) promocion).getAtraccionGratis().getNombre());
			statement.setString(9, "AxB");
		}
		
		if (promocion.getClass().getSimpleName().equals(PromocionPorcentual.class.getSimpleName())) {
			statement.setObject(8, ((PromocionPorcentual) promocion).getDescuento());
			statement.setString(9, "PORCENTUAL");
		}
		
		if (promocion.getClass().getSimpleName().equals(PromocionAbsoluta.class.getSimpleName())) {
			statement.setDouble(5, ((PromocionAbsoluta)promocion).getMonto());
			statement.setString(9, "ABSOLUTA");
		}

		int rows = statement.executeUpdate();

		return rows;

	}

	/*
	 * Busca en la base de datos y devuelve una promocion a partir de su ID
	 */
	public Promocion consultarID_Promo(int promo) throws SQLException {
		try {
			String sql = "SELECT * FROM Promocion WHERE ID_Promocion=?";

			Connection conn = ConnectionProvider.getConnection();
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setInt(1, promo);
			ResultSet rows = statement.executeQuery();
			Promocion pr = null;

			while (rows.next()) {
				pr = toPromo(rows);
			}
			return pr;
		} catch (Exception e) {
			throw new MissingDataException(e);
		}
	}

	/*
	 * Actualiza el nombre de una promocion
	 */
	@Override
	public int update(Promocion promocion) throws SQLException {
		String sql = "UPDATE Promocion SET Nombre = ?  WHERE Nombre  = ?";
		Connection conn = ConnectionProvider.getConnection();

		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, promocion.getNombre());
		statement.setObject(2, promocion.getNombre());
		int rows = statement.executeUpdate();

		return rows;

	}

	/*
	 * Borra una promocion
	 */
	@Override
	public int delete(Promocion promocion) throws SQLException {
		String sql = "DELETE FROM Promocion WHERE Nombre LIKE ?";
		Connection conn = ConnectionProvider.getConnection();

		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(3, promocion.getNombre());
		int rows = statement.executeUpdate();

		return rows;

	}

	/*
	 * Cuenta todas las promociones
	 */
	public int countAll() throws SQLException {
		String sql = "SELECT COUNT(1) AS TOTAL FROM Promocion";
		Connection conn = ConnectionProvider.getConnection();
		PreparedStatement statement = conn.prepareStatement(sql);
		ResultSet resultados = statement.executeQuery();

		resultados.next();
		int total = resultados.getInt("TOTAL");

		return total;
	}

	/*
	 * Pasa los datos para la creacion de una promocion
	 */
	private Promocion toPromo(ResultSet resultados) throws Exception {

		TipoAtraccion tipoAtraccion = TipoAtraccion.valueOf(resultados.getString(5));
		Atraccion[] packAtracciones = atraccionesDeLaPromocion(resultados.getLong(2), resultados.getLong(3));
		String nombre = resultados.getString(4);
		String promocionTipo = resultados.getString(10);
		Promocion promo = null;
		promo = creacionPromo(resultados, tipoAtraccion, packAtracciones, nombre, promocionTipo, promo);
		return promo;

	}

	/*
	 * Usando los datos pasados por toPromo, instancia algun tipo de promocion
	 */
	private Promocion creacionPromo(ResultSet resultados, TipoAtraccion tipoAtraccion, Atraccion[] packAtracciones,
			String nombre, String promocionTipo, Promocion promo) throws SQLException {
		if (promocionTipo.equals("AxB")) {
			Atraccion gratis = atraccionDao.buscarPorId(resultados.getLong(8));
			promo = new PromocionAxB(nombre, packAtracciones, tipoAtraccion, gratis);
		} else if (promocionTipo.equals("PORCENTUAL")) {
			int descuento = resultados.getInt(9);
			promo = new PromocionPorcentual(nombre, packAtracciones, tipoAtraccion, descuento);
		} else if (promocionTipo.equals("ABSOLUTA")) {
			double monto = resultados.getInt(6);
			promo = new PromocionAbsoluta(nombre, packAtracciones, tipoAtraccion, monto);
		}
		return promo;
	}

	/*
	 * Carga las atracciones de la promocion
	 */
	private Atraccion[] atraccionesDeLaPromocion(Long atraccion1, Long atraccion2) throws Exception {
		Atraccion[] packs = new Atraccion[2];
		try {

			Connection conn = ConnectionProvider.getConnection();
			PreparedStatement statement = conn.prepareStatement(sqlAtraccion());
			statement.setLong(1, atraccion1);
			ResultSet result = statement.executeQuery();

			while (result.next()) {
				packs[0] = atraccionDao.toAtraccion(result);
			}
			statement.setLong(1, atraccion2);
			ResultSet result2 = statement.executeQuery();
			while (result2.next()) {
				packs[1] = atraccionDao.toAtraccion(result2);
			}
			return packs;
		} catch (Exception e) {
			throw new Exception();
		}
	}

	/*
	 * sql utilizado en el mï¿½todo atraccionesDeLaPromocion
	 */
	private String sqlAtraccion() {
		String sql = "select *" + "from Atraccion WHERE ID_Atraccion = ?";
		return sql;
	}

	/*
	 * Busca y devuelve todas las promociones de la base de datos
	 */
	@Override
	public List<Promocion> findAll() throws SQLException {

		String sql = "SELECT * FROM Promocion WHERE Estado <> 0";
		Connection conn = ConnectionProvider.getConnection();
		PreparedStatement statement = conn.prepareStatement(sql);
		ResultSet resultados = statement.executeQuery();

		List<Promocion> promo = new LinkedList<Promocion>();
		while (resultados.next()) {
			try {
				promo.add(toPromo(resultados));
			} catch (Exception e) {

				throw new MissingDataException(e);
			}
		}
		return promo;
	}

	@Override
	public Promocion find(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int deleteLogico(Promocion promocion) throws SQLException {
		try {
			String sql = "UPDATE Promocion SET Estado = ? WHERE ID_Promocion = ?";
			Connection conn = ConnectionProvider.getConnection();

			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setInt(1, 0);
			statement.setLong(2, find(promocion.getNombre()));

			int rows = statement.executeUpdate();

			return rows;
		} catch (Exception e) {
			throw new MissingDataException(e);
		}
	}
	
	@Override
	public int find(String nombre) throws SQLException {
		

		String sql = "SELECT ID_Promocion, Nombre FROM Promocion WHERE Nombre LIKE \"%" + nombre + "%\"";

		Connection conn = ConnectionProvider.getConnection();
		PreparedStatement statement = conn.prepareStatement(sql);
		ResultSet resultados = statement.executeQuery();

		
		return Integer.parseInt(resultados.getString(1));

	}

	@Override
	public Promocion buscarPorId(Long IdPromocion) {
		try {
			String sql = " SELECT Promocion.ID_Promocion, Promocion.Nombre,Promocion.Tipo "
					   + " FROM Promocion" 
					   + " WHERE Promocion.ID_Promocion = ?";
			Connection conn = ConnectionProvider.getConnection();
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setLong(1, IdPromocion);
			ResultSet resultados = statement.executeQuery();

			Promocion promocion = null;

			if (resultados.next()) {
				promocion = toPromocion(resultados);
			}

			return promocion;
		} catch (Exception e) {
			throw new MissingDataException(e);
		}
	}

	private Promocion toPromocion(ResultSet resultados) throws SQLException {
		String nombre = resultados.getString(2);
		return new PromocionAbsoluta(nombre, null, null, 0);
	}
@Override
	public int update(Promocion promocion, String nombre) throws SQLException {
		String sql = "UPDATE Promocion SET Nombre = ?  WHERE Nombre LIKE ? ";
		Connection conn = ConnectionProvider.getConnection();

		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setString(1, nombre);
		statement.setObject(2, promocion.getNombre());
		int rows = statement.executeUpdate();

		return rows;

	}

}
