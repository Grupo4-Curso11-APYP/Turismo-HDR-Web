package model;

public enum TipoAtraccion {
          AVENTURA, DEGUSTACION, PAISAJE;
}
